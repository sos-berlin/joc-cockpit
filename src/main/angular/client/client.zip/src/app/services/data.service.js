/*
import { Injectable } from '@angular/core';
import { BehaviourSubject } from 'rxjs';

@Injectable()
export class DataService {
    private messageSource = new BehaviourSubject<string>('default message');
    currentMessage = this.messageSource.asObservable();

    constructor() {
    }

    changeMessage(message: string) {
        this.messageSource.next(message)
    }

}
*/
//# sourceMappingURL=data.service.js.map