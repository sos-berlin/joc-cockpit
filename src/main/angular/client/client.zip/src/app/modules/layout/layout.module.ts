import {NgModule} from '@angular/core';
import {LayoutRoutingModule} from './layout-routing.module';
import {LayoutComponent} from './layout.component';
import {HeaderComponent} from '../../components/header/header.component';
import {SharedModule} from '../shared/shared.module';
import {DataService} from '../../services/data.service';
import {SaveService} from '../../services/save.service';
import {LogModule} from '../log/log.module';
import {DashboardModule} from '../dashboard/dashboard.module';
import {UserModule} from '../user/user.module';
import {ErrorComponent} from '../error/error.component';

@NgModule({
  imports: [
    SharedModule,
    LayoutRoutingModule,
    LogModule,
    DashboardModule,
    UserModule
  ],
  declarations: [
    LayoutComponent,
    HeaderComponent,
    ErrorComponent
  ],
  providers: [
    DataService,
    SaveService
  ]
})
export class LayoutModule {
}
