import {Component} from '@angular/core';

@Component({
  selector: 'app-resource',
  templateUrl: './resource.component.html'
})
export class ResourceComponent {
  constructor() {
  }
}
